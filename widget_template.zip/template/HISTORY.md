# Slider Change History

@VERSION@

## 1.0.0
first release
